"use client";

import { useEffect, useState } from "react";

/**
 * ConvLab — Landing Page (Variante A: "The Diff")
 * Stack: Next.js 14 App Router + Tailwind. Drop in app/page.tsx.
 *
 * Setup:
 * 1. Tailwind: erweitere tailwind.config in "Fonts" Section unten beschrieben.
 * 2. Calendly: ersetze CALENDLY_URL durch deinen Link.
 * 3. Fonts: füge die <link> Tags aus app/layout.tsx hinzu (siehe Kommentar am Ende).
 */

const CALENDLY_URL = "https://calendly.com/DEIN-LINK/audit-call";

function useCalendly() {
  useEffect(() => {
    const s = document.createElement("script");
    s.src = "https://assets.calendly.com/assets/external/widget.js";
    s.async = true;
    document.body.appendChild(s);
    const l = document.createElement("link");
    l.href = "https://assets.calendly.com/assets/external/widget.css";
    l.rel = "stylesheet";
    document.head.appendChild(l);
    return () => {
      s.remove();
      l.remove();
    };
  }, []);
}

function openCalendly(e: React.MouseEvent) {
  e.preventDefault();
  // @ts-expect-error Calendly global
  if (window.Calendly) window.Calendly.initPopupWidget({ url: CALENDLY_URL });
}

export default function ConvLabLanding() {
  useCalendly();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main className="min-h-screen bg-[#0a0a0b] text-white font-sans antialiased selection:bg-emerald-400/30">
      {/* ===== NAV ===== */}
      <nav
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          scrolled ? "bg-[#0a0a0b]/80 backdrop-blur-md border-b border-white/[0.06]" : ""
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-grotesk font-semibold text-lg tracking-tight">
            <span className="text-emerald-400">◆</span> ConvLab
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-neutral-400">
            <a href="#how" className="hover:text-white transition">Ablauf</a>
            <a href="#proof" className="hover:text-white transition">Ergebnisse</a>
            <a href="#pricing" className="hover:text-white transition">Pakete</a>
          </div>
          <a
            href={CALENDLY_URL}
            onClick={openCalendly}
            className="text-sm font-medium bg-emerald-400 text-emerald-950 px-4 py-2 rounded-lg hover:-translate-y-0.5 transition-transform"
          >
            Call buchen
          </a>
        </div>
      </nav>

      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden pt-36 pb-28 px-6 [background:radial-gradient(120%_120%_at_50%_0%,#12131a_0%,#0a0a0b_55%)]">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-[1.05fr_1fr] gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 font-mono text-[13px] text-emerald-300 tracking-tight mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_12px_#34d399] animate-pulse" />
              VERIFIED FIXES · NICHT NUR EMPFEHLUNGEN
            </div>
            <h1 className="font-grotesk text-[clamp(2.4rem,6vw,3.4rem)] leading-[1.04] font-semibold tracking-tight mb-5">
              Andere schicken dir<br />einen Report.<br />
              <span className="text-emerald-400">Wir schicken den Fix.</span>
            </h1>
            <p className="text-neutral-400 text-lg leading-relaxed max-w-md mb-8">
              ConvLab auditiert deinen SaaS-Funnel, findet die Conversion-Killer und
              liefert die verifizierten Fixes – deploy-ready. Kein 40-Seiten-PDF, das
              niemand umsetzt.
            </p>
            <div className="flex gap-3.5 items-center flex-wrap">
              <a
                href={CALENDLY_URL}
                onClick={openCalendly}
                className="bg-emerald-400 text-emerald-950 font-semibold text-[15px] px-7 py-3.5 rounded-[10px] shadow-[0_8px_30px_rgba(52,211,153,.25)] hover:-translate-y-0.5 hover:shadow-[0_12px_40px_rgba(52,211,153,.4)] transition-all"
              >
                Audit-Call buchen →
              </a>
              <a
                href="#proof"
                className="border border-white/10 px-6 py-3.5 rounded-[10px] text-[15px] hover:border-white/25 transition"
              >
                Beispiel-Report
              </a>
            </div>
            <p className="mt-6 font-mono text-[13px] text-neutral-500">
              // Erster Fix in 7 Tagen · Festpreis · DACH-Markt
            </p>
          </div>

          {/* Diff Card */}
          <div className="bg-[#101116] border border-white/[0.08] rounded-2xl p-2 shadow-[0_30px_80px_rgba(0,0,0,.5)]">
            <div className="flex gap-1.5 px-3.5 py-3">
              <span className="w-[11px] h-[11px] rounded-full bg-[#ff5f57]" />
              <span className="w-[11px] h-[11px] rounded-full bg-[#febc2e]" />
              <span className="w-[11px] h-[11px] rounded-full bg-[#28c840]" />
            </div>
            <div className="font-mono text-[13.5px] leading-[1.9] px-4 pb-4">
              <div className="px-2.5 text-neutral-500">checkout_flow.tsx</div>
              {[
                { t: "rem", m: "−", x: "3-step signup, kein trust signal" },
                { t: "rem", m: "−", x: "CTA below fold, generisch" },
                { t: "add", m: "+", x: "1-step signup + social proof" },
                { t: "add", m: "+", x: "CTA above fold, spezifisch" },
              ].map((l, i) => (
                <div
                  key={i}
                  className={`px-2.5 rounded flex gap-2.5 ${
                    l.t === "rem"
                      ? "bg-red-400/[0.08] text-red-300"
                      : "bg-emerald-400/10 text-emerald-300"
                  }`}
                >
                  <span className="w-3.5 shrink-0">{l.m}</span>
                  {l.x}
                </div>
              ))}
              <div className="mt-3.5 pt-3.5 px-2.5 border-t border-dashed border-white/10 flex justify-between items-center font-grotesk">
                <span className="text-sm text-neutral-400">Conversion Rate</span>
                <span className="text-[26px] font-bold text-emerald-400">2.1% → 4.8%</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== LOGOS / TRUST STRIP ===== */}
      <section className="border-y border-white/[0.06] py-7 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-center gap-10 flex-wrap font-mono text-[12px] tracking-widest text-neutral-600 uppercase">
          <span>Next.js Funnels</span><span>·</span>
          <span>Stripe Checkouts</span><span>·</span>
          <span>SaaS Pricing Pages</span><span>·</span>
          <span>DACH B2B</span>
        </div>
      </section>

      {/* ===== HOW IT WORKS ===== */}
      <section id="how" className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="font-mono text-[13px] text-emerald-300 mb-3">// Ablauf</div>
          <h2 className="font-grotesk text-4xl font-semibold tracking-tight mb-16 max-w-xl">
            Drei Schritte. Ein deploy-ready Fix.
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                n: "01",
                t: "Audit",
                d: "Wir analysieren deinen Funnel mit Session-Daten, Heatmaps und einer manuellen UX-Prüfung. Jedes Leck wird priorisiert nach Impact.",
              },
              {
                n: "02",
                t: "Fix",
                d: "Statt Empfehlungen liefern wir den fertigen Code-Fix. Du bekommst einen Branch oder PR – getestet, nicht geraten.",
              },
              {
                n: "03",
                t: "Verify",
                d: "Wir messen den Effekt nach Deploy. Kein Uplift, kein Bullshit – die Zahl steht im Report, nicht eine Vermutung.",
              },
            ].map((s) => (
              <div
                key={s.n}
                className="bg-[#101116] border border-white/[0.08] rounded-2xl p-7 hover:border-emerald-400/30 transition-colors"
              >
                <div className="font-mono text-emerald-400 text-sm mb-5">{s.n}</div>
                <h3 className="font-grotesk text-xl font-semibold mb-3">{s.t}</h3>
                <p className="text-neutral-400 text-[15px] leading-relaxed">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PROOF ===== */}
      <section id="proof" className="py-28 px-6 [background:radial-gradient(100%_100%_at_50%_0%,#101218_0%,#0a0a0b_60%)]">
        <div className="max-w-6xl mx-auto text-center">
          <div className="font-mono text-[13px] text-emerald-300 mb-3">// Ergebnisse</div>
          <h2 className="font-grotesk text-4xl font-semibold tracking-tight mb-16">
            Fixes, die sich in Zahlen zeigen.
          </h2>
          <div className="grid md:grid-cols-3 gap-px bg-white/[0.06] rounded-2xl overflow-hidden border border-white/[0.06]">
            {[
              { num: "+38%", desc: "Ø Conversion-Uplift" },
              { num: "7 Tage", desc: "bis zum ersten Fix" },
              { num: "100%", desc: "verifiziert deployed" },
            ].map((s) => (
              <div key={s.desc} className="bg-[#0d0e12] py-12 px-6">
                <div className="font-grotesk text-5xl font-bold tracking-tight text-emerald-400">
                  {s.num}
                </div>
                <div className="text-neutral-400 text-sm mt-3">{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PRICING ===== */}
      <section id="pricing" className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="font-mono text-[13px] text-emerald-300 mb-3">// Pakete</div>
          <h2 className="font-grotesk text-4xl font-semibold tracking-tight mb-4 max-w-xl">
            Festpreis. Kein Retainer-Zwang.
          </h2>
          <p className="text-neutral-400 mb-16 max-w-lg">
            Schneller Cashflow für dich, schneller Einstieg für deinen Kunden. Starte
            klein, skaliere bei Bedarf.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: "Spot-Fix",
                price: "CHF 490",
                tag: "Entry",
                feats: ["1 Funnel-Seite", "Top-3 Conversion-Lecks", "1 deploy-ready Fix", "Lieferung in 7 Tagen"],
                highlight: false,
              },
              {
                name: "Full Audit",
                price: "CHF 1’490",
                tag: "Beliebt",
                feats: ["Kompletter Funnel", "Priorisierte Leck-Liste", "Bis zu 5 Fixes", "Verify-Report nach Deploy"],
                highlight: true,
              },
              {
                name: "Retainer",
                price: "ab CHF 990/Mo",
                tag: "Skalierung",
                feats: ["Laufende Optimierung", "Monatliche Fixes", "A/B-Test-Setup", "Direkter Slack-Zugang"],
                highlight: false,
              },
            ].map((p) => (
              <div
                key={p.name}
                className={`rounded-2xl p-7 border transition-colors ${
                  p.highlight
                    ? "bg-emerald-400/[0.06] border-emerald-400/40"
                    : "bg-[#101116] border-white/[0.08] hover:border-white/20"
                }`}
              >
                <div className="flex justify-between items-center mb-5">
                  <h3 className="font-grotesk text-lg font-semibold">{p.name}</h3>
                  <span
                    className={`font-mono text-[11px] px-2 py-1 rounded ${
                      p.highlight ? "bg-emerald-400 text-emerald-950" : "bg-white/10 text-neutral-300"
                    }`}
                  >
                    {p.tag}
                  </span>
                </div>
                <div className="font-grotesk text-3xl font-bold mb-6">{p.price}</div>
                <ul className="space-y-3 mb-8">
                  {p.feats.map((f) => (
                    <li key={f} className="flex gap-2.5 text-[14.5px] text-neutral-300">
                      <span className="text-emerald-400">✓</span> {f}
                    </li>
                  ))}
                </ul>
                <a
                  href={CALENDLY_URL}
                  onClick={openCalendly}
                  className={`block text-center py-3 rounded-[10px] text-[15px] font-medium transition ${
                    p.highlight
                      ? "bg-emerald-400 text-emerald-950 hover:-translate-y-0.5"
                      : "border border-white/15 hover:border-white/35"
                  }`}
                >
                  Call buchen
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FINAL CTA ===== */}
      <section className="py-28 px-6">
        <div className="max-w-3xl mx-auto text-center bg-[#101116] border border-white/[0.08] rounded-3xl p-14">
          <h2 className="font-grotesk text-4xl font-semibold tracking-tight mb-5">
            Finde dein erstes Leck.<br />
            <span className="text-emerald-400">Gratis im Call.</span>
          </h2>
          <p className="text-neutral-400 mb-9 max-w-md mx-auto">
            15 Minuten. Wir schauen live auf deinen Funnel und zeigen dir den größten
            Hebel – ohne Verkaufsdruck.
          </p>
          <a
            href={CALENDLY_URL}
            onClick={openCalendly}
            className="inline-block bg-emerald-400 text-emerald-950 font-semibold text-base px-9 py-4 rounded-xl shadow-[0_8px_30px_rgba(52,211,153,.25)] hover:-translate-y-0.5 hover:shadow-[0_14px_44px_rgba(52,211,153,.4)] transition-all"
          >
            Kostenlosen Audit-Call buchen →
          </a>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="border-t border-white/[0.06] py-10 px-6">
        <div className="max-w-6xl mx-auto flex justify-between items-center flex-wrap gap-4 text-sm text-neutral-500">
          <div className="flex items-center gap-2 font-grotesk font-semibold text-white">
            <span className="text-emerald-400">◆</span> ConvLab
          </div>
          <div className="font-mono text-[13px]">© {new Date().getFullYear()} · Conversion Audits · DACH</div>
        </div>
      </footer>
    </main>
  );
}

/*
=========================================================
SETUP — 2 Minuten
=========================================================

1) FONTS — in app/layout.tsx im <head>:

<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
<link
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"
  rel="stylesheet"
/>

2) TAILWIND — in tailwind.config.ts unter theme.extend:

fontFamily: {
  sans: ['Inter', 'sans-serif'],
  grotesk: ['"Space Grotesk"', 'sans-serif'],
  mono: ['"IBM Plex Mono"', 'monospace'],
},

3) CALENDLY — CALENDLY_URL oben durch deinen Link ersetzen.

=========================================================
*/
